'use client'

import type { User } from '@/lib/types'
import { faGraduationCap, faFolderOpen, faFileAlt, faChartLine, faDesktop } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React from 'react'

interface CBTPageProps {
  user: User
}

export function CBTDashboardPlaceholder({ user }: CBTPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-800">CBT Dashboard</h1>
          <p className="text-slate-500 mt-1">Selamat datang, {user.fullName || user.username}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {[
            { label: 'Bank Soal', count: 0, icon: faFolderOpen, color: 'bg-blue-500' },
            { label: 'Ujian Aktif', count: 0, icon: faFileAlt, color: 'bg-amber-500' },
            { label: 'Peserta Ujian', count: 0, icon: faGraduationCap, color: 'bg-emerald-500' },
          ].map((stat) => (
            <div key={stat.label} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center`}>
                  <FontAwesomeIcon icon={stat.icon} className="text-white text-xl" />
                </div>
                <span className="text-4xl font-bold text-slate-800">{stat.count}</span>
              </div>
              <p className="text-slate-500 font-medium">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center">
          <FontAwesomeIcon icon={faDesktop} className="text-slate-300 text-5xl mb-4" />
          <h2 className="text-xl font-semibold text-slate-700 mb-2">CBT Dashboard</h2>
          <p className="text-slate-400">Fitur dalam pengembangan. Bank soal, pengelolaan ujian, dan nilai akan segera hadir.</p>
        </div>
      </div>
    </div>
  )
}

export function CBTBankSoalPlaceholder({ user: _user }: CBTPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-800">Bank Soal CBT</h1>
          <p className="text-slate-500 mt-1">Kelola soal ujian berbasis komputer</p>
        </div>
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center">
          <FontAwesomeIcon icon={faFolderOpen} className="text-slate-300 text-5xl mb-4" />
          <h2 className="text-xl font-semibold text-slate-700 mb-2">Bank Soal</h2>
          <p className="text-slate-400">Kelola bank soal untuk ujian CBT. Buat, edit, dan organise soal dengan berbagai tipe.</p>
        </div>
      </div>
    </div>
  )
}

export function CBTUjianPlaceholder({ user: _user }: CBTPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-800">Kelola Ujian</h1>
          <p className="text-slate-500 mt-1">Buat and kelola ujian CBT</p>
        </div>
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center">
          <FontAwesomeIcon icon={faFileAlt} className="text-slate-300 text-5xl mb-4" />
          <h2 className="text-xl font-semibold text-slate-700 mb-2">Kelola Ujian</h2>
          <p className="text-slate-400">Buat jadwal ujian, atur durasi, dan kelola peserta ujian CBT.</p>
        </div>
      </div>
    </div>
  )
}

export function CBTNilaiPlaceholder({ user: _user }: CBTPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-800">Nilai CBT</h1>
          <p className="text-slate-500 mt-1">Lihat dan kelola hasil ujian siswa</p>
        </div>
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center">
          <FontAwesomeIcon icon={faChartLine} className="text-slate-300 text-5xl mb-4" />
          <h2 className="text-xl font-semibold text-slate-700 mb-2">Nilai CBT</h2>
          <p className="text-slate-400">Lihat hasil ujian, analisis performa siswa, dan kelola penskoran.</p>
        </div>
      </div>
    </div>
  )
}

export function CBTPantauPlaceholder({ user: _user }: CBTPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-800">Pantau Ujian</h1>
          <p className="text-slate-500 mt-1">Monitor jalannya ujian secara real-time</p>
        </div>
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center">
          <FontAwesomeIcon icon={faDesktop} className="text-slate-300 text-5xl mb-4" />
          <h2 className="text-xl font-semibold text-slate-700 mb-2">Pantau Ujian</h2>
          <p className="text-slate-400">Pantau jalannya ujian secara real-time. Deteksi pelanggaran dan keamanan ujian.</p>
        </div>
      </div>
    </div>
  )
}