"use server"
import { prisma } from '@/lib/prisma'
import { getSupabaseAdmin } from '@/lib/supabase-cbt'

/**
 * Log a security violation during an exam attempt.
 */
export async function logSecurityViolationAction(
    attemptId: string,
    eventType: string,
    metadata: Record<string, any> = {}
) {
    try {
        await prisma.cbt_attempt_security_logs.create({
            data: { attempt_id: attemptId, event_type: eventType, metadata }
        })

        const updates: Record<string, any> = {}
        if (eventType === 'tab_switch' || eventType === 'blur') {
            const attempt = await prisma.cbt_exam_attempts.findUnique({
                where: { id: attemptId },
                select: { tab_switch_count: true, warning_count: true }
            })
            if (attempt) {
                updates.tab_switch_count = (attempt.tab_switch_count || 0) + 1
                updates.warning_count = (attempt.warning_count || 0) + 1
            }
        } else {
            const attempt = await prisma.cbt_exam_attempts.findUnique({
                where: { id: attemptId },
                select: { warning_count: true }
            })
            if (attempt) updates.warning_count = (attempt.warning_count || 0) + 1
        }

        if (Object.keys(updates).length > 0) {
            await prisma.cbt_exam_attempts.update({
                where: { id: attemptId },
                data: updates
            })
        }

        return { success: true, warningCount: updates.warning_count }
    } catch (error: any) {
        console.error('Security: Log violation error:', error)
        return { success: false, error: error.message }
    }
}

/**
 * Reset exam attempt — allows student to continue with saved answers.
 */
export async function resetExamAttemptAction(attemptId: string) {
    try {
        const attempt = await prisma.cbt_exam_attempts.findUnique({
            where: { id: attemptId },
            select: { id: true, status: true }
        })

        if (!attempt) return { success: false, error: 'Attempt tidak ditemukan' }
        if (attempt.status !== 'auto_submitted') {
            return { success: false, error: 'Hanya ujian yang di-terminate sistem yang bisa di-reset' }
        }

        await prisma.cbt_exam_attempts.update({
            where: { id: attemptId },
            data: { status: 'in_progress', finished_at: null, warning_count: 0, tab_switch_count: 0 }
        })

        await prisma.cbt_attempt_security_logs.create({
            data: { attempt_id: attemptId, event_type: 'RESET_BY_PROCTOR', metadata: { resetAt: new Date().toISOString() } }
        })

        return { success: true }
    } catch (error: any) {
        console.error('Security: Reset attempt error:', error)
        return { success: false, error: error.message }
    }
}

/**
 * Force logout a student from exam.
 */
export async function forceLogoutStudentAction(userId: string, attemptId: string, reason: string) {
    try {
        await prisma.cbt_exam_attempts.update({
            where: { id: attemptId },
            data: { status: 'auto_submitted', finished_at: new Date().toISOString() }
        })

        try {
            const supabaseAdmin = getSupabaseAdmin()
            await supabaseAdmin.auth.admin.signOut(userId, 'global')
        } catch (authErr) {
            console.error('Signout error:', authErr)
        }

        await prisma.cbt_attempt_security_logs.create({
            data: { attempt_id: attemptId, event_type: 'FORCE_TERMINATED', metadata: { reason } }
        })

        return { success: true }
    } catch (error: any) {
        console.error('Security: Force logout error:', error)
        return { success: false, error: error.message }
    }
}