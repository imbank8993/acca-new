"use server"
import { prisma } from '@/lib/prisma'
import { getSupabaseAdmin } from '@/lib/supabase-cbt'
import { regradeExamAttemptsByQuestion } from './cbt-grading'

export type QuestionType = 'mcq' | 'mcq_complex' | 'true_false' | 'matching' | 'categorization' | 'short_answer' | 'essay'

// =============================================================================
// QUESTION CRUD
// =============================================================================

export async function saveQuestionAction(data: {
    id?: string
    bankId: string
    orgId: string
    type: QuestionType
    questionText: string
    difficulty: 'easy' | 'medium' | 'hard'
    scoreDefault: number
    metadata?: any
    stimulusId?: string | null
    instructionId?: string | null
    options?: { id?: string; text: string; isCorrect: boolean; order: number; weight: number; metadata?: any }[]
}) {
    try {
        let question: any
        if (data.id) {
            question = await prisma.cbt_bank_questions.upsert({
                where: { id: data.id },
                create: {
                    id: data.id,
                    bank_id: data.bankId,
                    organization_id: data.orgId,
                    type: data.type,
                    question_text: data.questionText,
                    difficulty: data.difficulty,
                    score_default: data.scoreDefault,
                    metadata: data.metadata || {},
                    stimulus_id: data.stimulusId || null,
                    instruction_id: data.instructionId || null,
                },
                update: {
                    bank_id: data.bankId,
                    organization_id: data.orgId,
                    type: data.type,
                    question_text: data.questionText,
                    difficulty: data.difficulty,
                    score_default: data.scoreDefault,
                    metadata: data.metadata || {},
                    stimulus_id: data.stimulusId || null,
                    instruction_id: data.instructionId || null,
                }
            })
        } else {
            question = await prisma.cbt_bank_questions.create({
                data: {
                    bank_id: data.bankId,
                    organization_id: data.orgId,
                    type: data.type,
                    question_text: data.questionText,
                    difficulty: data.difficulty,
                    score_default: data.scoreDefault,
                    metadata: data.metadata || {},
                    stimulus_id: data.stimulusId || null,
                    instruction_id: data.instructionId || null,
                }
            })
        }

        if (data.options && data.options.length > 0) {
            const seen = new Set<string>()
            const uniqueOptions = data.options.filter((opt) => {
                const text = (opt.text || '').trim()
                if (text === '') return true
                const key = `${text}_${opt.isCorrect}`
                if (seen.has(key)) return false
                seen.add(key)
                return true
            })

            const payloadOptions = uniqueOptions.map((opt, idx) => ({
                id: opt.id,
                question_id: question.id,
                option_text: opt.text,
                is_correct: opt.isCorrect,
                order: idx,
                weight: opt.weight || 1,
                metadata: (opt as any).metadata || {},
            }))

            const optionsToUpdate = payloadOptions.filter((o) => o.id)
            const optionsToInsert = payloadOptions.filter((o) => !o.id).map(({ id, ...rest }) => rest)
            const currentOptionIds = optionsToUpdate.map((o) => o.id!)

            if (currentOptionIds.length > 0) {
                await prisma.cbt_bank_question_options.deleteMany({
                    where: {
                        question_id: question.id,
                        NOT: { id: { in: currentOptionIds } }
                    }
                })
            } else {
                await prisma.cbt_bank_question_options.deleteMany({
                    where: { question_id: question.id }
                })
            }

            if (optionsToInsert.length > 0) {
                await prisma.cbt_bank_question_options.createMany({
                    data: optionsToInsert
                })
            }
            for (const opt of optionsToUpdate) {
                await prisma.cbt_bank_question_options.update({
                    where: { id: opt.id },
                    data: opt
                })
            }
        }

        if (data.id) {
            regradeExamAttemptsByQuestion(question.id).catch((err) => console.error('[saveQuestionAction] Background regrade error:', err))
        }

        await prisma.cbt_question_banks.update({
            where: { id: data.bankId },
            data: { updated_at: new Date().toISOString() }
        })

        return { success: true, id: question.id }
    } catch (error: any) {
        console.error('Question: Save error:', error)
        return { success: false, error: error.message }
    }
}

export async function updateQuestionMetadataAction(questionId: string, metadataUpdates: Record<string, any>) {
    try {
        const q = await prisma.cbt_bank_questions.findUnique({
            where: { id: questionId },
            select: { metadata: true, bank_id: true }
        })
        if (!q) return { success: false, error: 'Question not found' }
        const newMetadata = { ...((q.metadata as any) || {}), ...metadataUpdates }
        await prisma.cbt_bank_questions.update({
            where: { id: questionId },
            data: { metadata: newMetadata }
        })
        if (q.bank_id) {
            await prisma.cbt_question_banks.update({
                where: { id: q.bank_id },
                data: { updated_at: new Date().toISOString() }
            })
        }
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function getBankQuestions(bankId: string) {
    try {
        const data = await prisma.cbt_bank_questions.findMany({
            where: { bank_id: bankId },
            include: {
                cbt_bank_question_options: true,
                cbt_question_stimuli: true,
                cbt_question_instructions: true
            },
            orderBy: { created_at: 'asc' }
        })

        return (data || []).map((q: any) => ({
            ...q,
            stimulus: q.cbt_question_stimuli,
            instruction: q.cbt_question_instructions,
            bank_question_options: (() => {
                const opts = q.cbt_bank_question_options || []
                const seen = new Set<string>()
                return opts
                    .filter((o: any) => {
                        const text = (o.option_text || '').trim()
                        if (text === '') return true
                        const key = `${text}_${o.is_correct}`
                        if (seen.has(key)) return false
                        seen.add(key)
                        return true
                    })
                    .sort((a: any, b: any) => (a.order || 0) - (b.order || 0))
            })(),
        }))
    } catch (error) {
        return []
    }
}

// =============================================================================
// QUESTION BANK CRUD
// =============================================================================

export async function getQuestionBankAction(bankId: string) {
    return prisma.cbt_question_banks.findUnique({
        where: { id: bankId }
    })
}

export async function createQuestionBank(
    orgId: string,
    userId: string,
    title: string,
    description: string,
    subject: string,
    classLevel: string,
    iconIdentifier?: string,
    imageUrl?: string,
    tags?: string[],
    folderId?: string
) {
    try {
        const data = await prisma.cbt_question_banks.create({
            data: {
                organization_id: orgId,
                created_by: userId,
                title,
                description,
                subject,
                class_level: classLevel,
                is_published: false,
                icon_identifier: iconIdentifier,
                image_url: imageUrl,
                tags: tags || [],
                folder_id: folderId || null,
            }
        })
        return { success: true, id: data.id }
    } catch (err: any) {
        return { success: false, error: err.message }
    }
}

export async function updateQuestionBankAction(
    bankId: string,
    orgId: string,
    data: { title?: string; description?: string; subject?: string; classLevel?: string; iconIdentifier?: string; imageUrl?: string; tags?: string[]; folderId?: string | null }
) {
    try {
        const updates: any = {}
        if (data.title !== undefined) updates.title = data.title
        if (data.description !== undefined) updates.description = data.description
        if (data.subject !== undefined) updates.subject = data.subject
        if (data.classLevel !== undefined) updates.class_level = data.classLevel
        if (data.iconIdentifier !== undefined) updates.icon_identifier = data.iconIdentifier
        if (data.imageUrl !== undefined) updates.image_url = data.imageUrl
        if (data.tags !== undefined) updates.tags = data.tags
        if (data.folderId !== undefined) updates.folder_id = data.folderId || null
        await prisma.cbt_question_banks.updateMany({
            where: { id: bankId, organization_id: orgId },
            data: updates
        })
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function deleteQuestionBank(bankId: string, orgId: string) {
    try {
        await prisma.cbt_question_banks.deleteMany({
            where: { id: bankId, organization_id: orgId }
        })
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function listQuestionBanks(orgId: string, userId: string, onlyPublished?: boolean) {
    try {
        const where: any = { organization_id: orgId }
        if (onlyPublished) where.is_published = true

        const data = await prisma.cbt_question_banks.findMany({
            where,
            include: {
                cbt_profiles: { select: { full_name: true } },
                cbt_bank_questions: true,
                cbt_bank_folders: { select: { id: true, name: true } }
            },
            orderBy: { created_at: 'desc' }
        })

        let usersMap = new Map()
        try {
            const supabaseAdmin = getSupabaseAdmin()
            const { data: usersData } = await supabaseAdmin.auth.admin.listUsers()
            if (usersData?.users) usersData.users.forEach((u: any) => usersMap.set(u.id, u.email))
        } catch {
            // Optional auth backup
        }

        return (data || []).map((bank: any) => {
            const email = usersMap.get(bank.created_by) || ''
            const emailPrefix = email ? email.split('@')[0] : 'Unknown'
            let fullName = bank.cbt_profiles?.full_name
            if (!fullName || fullName === 'Unknown User' || fullName === 'Unknown') fullName = emailPrefix
            return {
                ...bank,
                profiles: bank.cbt_profiles,
                bank_folders: bank.cbt_bank_folders,
                question_count: bank.cbt_bank_questions?.length || 0,
                creator_name: fullName,
            }
        })
    } catch (err) {
        return []
    }
}

// =============================================================================
// FOLDER MANAGEMENT
// =============================================================================

export async function listBankFolders(orgId: string) {
    return prisma.cbt_bank_folders.findMany({
        where: { organization_id: orgId },
        orderBy: { created_at: 'asc' }
    })
}

export async function createBankFolder(orgId: string, userId: string, name: string) {
    try {
        if (!name.trim()) return { success: false, error: 'Nama folder wajib diisi.' }
        const data = await prisma.cbt_bank_folders.create({
            data: { organization_id: orgId, created_by: userId, name: name.trim() }
        })
        return { success: true, id: data.id }
    } catch (err: any) {
        return { success: false, error: err.message }
    }
}

export async function deleteQuestionAction(questionId: string, bankId: string) {
    try {
        const usedCount = await prisma.cbt_exam_attempt_questions.count({
            where: { question_id: questionId }
        })
        if (usedCount > 0) {
            const q = await prisma.cbt_bank_questions.findUnique({ where: { id: questionId }, select: { metadata: true } })
            const meta = { ...((q?.metadata as any) || {}), _deleted: true, _deleted_at: new Date().toISOString() }
            await prisma.cbt_bank_questions.update({
                where: { id: questionId },
                data: { metadata: meta }
            })
            await prisma.cbt_question_banks.update({
                where: { id: bankId },
                data: { updated_at: new Date().toISOString() }
            })
            return { success: false, error: 'Soal tidak bisa dihapus karena sudah digunakan di jawaban ujian siswa.' }
        }
        await prisma.cbt_bank_question_options.deleteMany({ where: { question_id: questionId } })
        await prisma.cbt_bank_questions.delete({ where: { id: questionId } })
        await prisma.cbt_question_banks.update({
            where: { id: bankId },
            data: { updated_at: new Date().toISOString() }
        })
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function toggleQuestionBankPublishAction(bankId: string, orgId: string, isPublished: boolean) {
    try {
        await prisma.cbt_question_banks.updateMany({
            where: { id: bankId, organization_id: orgId },
            data: { is_published: isPublished }
        })
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function updateQuestionsOrderAction(bankId: string, orderedIds: string[]) {
    try {
        for (const id of orderedIds) {
            const q = await prisma.cbt_bank_questions.findUnique({ where: { id }, select: { metadata: true } })
            const meta = { ...((q?.metadata as any) || {}), order_index: orderedIds.indexOf(id) }
            await prisma.cbt_bank_questions.update({
                where: { id },
                data: { metadata: meta }
            })
        }
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

// =============================================================================
// STIMULUS MANAGEMENT
// =============================================================================

export async function getStimuliByBank(bankId: string) {
    return prisma.cbt_question_stimuli.findMany({
        where: { bank_id: bankId },
        orderBy: { created_at: 'desc' }
    })
}

export async function createStimulus(orgId: string, bankId: string, title: string, content: string) {
    try {
        const data = await prisma.cbt_question_stimuli.create({
            data: { organization_id: orgId, bank_id: bankId, title, content }
        })
        return { success: true, id: data.id }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function updateStimulus(stimulusId: string, orgId: string, title: string, content: string) {
    try {
        await prisma.cbt_question_stimuli.updateMany({
            where: { id: stimulusId, organization_id: orgId },
            data: { title, content }
        })
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function deleteStimulus(stimulusId: string, orgId: string) {
    try {
        await prisma.cbt_question_stimuli.deleteMany({
            where: { id: stimulusId, organization_id: orgId }
        })
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

// =============================================================================
// INSTRUCTION MANAGEMENT
// =============================================================================

export async function getInstructionsByBank(bankId: string) {
    return prisma.cbt_question_instructions.findMany({
        where: { bank_id: bankId },
        orderBy: { created_at: 'desc' }
    })
}

export async function createInstruction(orgId: string, bankId: string, title: string, content: string) {
    try {
        const data = await prisma.cbt_question_instructions.create({
            data: { bank_id: bankId, title: title || null, content }
        })
        return { success: true, data }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function updateInstruction(instructionId: string, orgId: string, title: string, content: string) {
    try {
        const data = await prisma.cbt_question_instructions.update({
            where: { id: instructionId },
            data: { title: title || null, content, updated_at: new Date().toISOString() }
        })
        return { success: true, data }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function deleteInstruction(instructionId: string, orgId: string) {
    try {
        await prisma.cbt_question_instructions.delete({ where: { id: instructionId } })
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}