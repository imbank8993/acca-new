"use server"
import { prisma } from '@/lib/prisma'
import { getSupabaseAdmin } from '@/lib/supabase-cbt'

// =============================================================================
// HELPERS
// =============================================================================

const toUTCISO = (wibLocalStr: string | undefined): string | null => {
    if (!wibLocalStr || wibLocalStr.trim() === '') return null
    const match = wibLocalStr.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.\d+)?)?Z?$/)
    if (!match) {
        const fallback = new Date(wibLocalStr)
        if (!isNaN(fallback.getTime())) return fallback.toISOString()
        return null
    }
    const [, year, month, day, hour, minute, second] = match
    const wibDate = Date.UTC(parseInt(year), parseInt(month) - 1, parseInt(day), parseInt(hour), parseInt(minute), second ? parseInt(second) : 0, 0)
    const utcTimestamp = wibDate - 7 * 60 * 60 * 1000
    const utcDate = new Date(utcTimestamp)
    return isNaN(utcDate.getTime()) ? null : utcDate.toISOString()
}

// =============================================================================
// ORGANIZATION / PROCTOR
// =============================================================================

/**
 * Get organization for a proctor user (via organization_members table).
 */
export async function getProctorOrganization(userId: string) {
    const member = await prisma.cbt_organization_members.findFirst({
        where: { user_id: userId },
        include: { cbt_organizations: true }
    })
    if (!member) return null
    return {
        id: member.organization_id,
        name: member.cbt_organizations?.name,
        allow_token_system: member.cbt_organizations?.allow_token_system,
    }
}

export async function getOrganizationStats(orgId: string) {
    const now = new Date().toISOString()
    try {
        const [totalMembers, totalBanks, examsData] = await Promise.all([
            prisma.cbt_organization_members.count({ where: { organization_id: orgId } }),
            prisma.cbt_question_banks.count({ where: { organization_id: orgId } }),
            prisma.cbt_exams.findMany({
                where: { organization_id: orgId },
                select: { is_published: true, status: true, start_time: true, end_time: true }
            })
        ])
        const draft = examsData.filter((e: any) => !e.is_published).length
        const ongoing = examsData.filter((e: any) => !!e.is_published && e.status === 'active' && (!e.start_time || new Date(e.start_time).toISOString() <= now) && (!e.end_time || new Date(e.end_time).toISOString() >= now)).length
        const finished = examsData.filter((e: any) => e.status === 'finished' || (!!e.is_published && e.status === 'active' && e.end_time && new Date(e.end_time).toISOString() < now)).length
        return { totalMembers, totalBanks, ongoingExams: ongoing, draftExams: draft, finishedExams: finished }
    } catch (error) {
        return { totalMembers: 0, totalBanks: 0, ongoingExams: 0, draftExams: 0, finishedExams: 0 }
    }
}

export async function listOrganizationMembers(orgId: string) {
    const members = await prisma.cbt_organization_members.findMany({
        where: { organization_id: orgId },
        include: {
            cbt_profiles: {
                include: {
                    cbt_class_members: {
                        include: { cbt_classes: true }
                    }
                }
            },
            cbt_member_roles: {
                include: { cbt_roles: true }
            }
        }
    })
    
    let emailMap = new Map()
    try {
        const supabaseAdmin = getSupabaseAdmin()
        const { data: authData } = await supabaseAdmin.auth.admin.listUsers()
        if (authData?.users) authData.users.forEach((u: any) => emailMap.set(u.id, u.email))
    } catch {
        // Fallback if auth admin API fails
    }

    return members.map((m: any) => ({
        id: m.id,
        userId: m.user_id,
        is_active: m.is_active ?? true,
        fullName: m.cbt_profiles?.full_name || 'No Name',
        identityNumber: m.cbt_profiles?.identity_number || '-',
        email: emailMap.get(m.user_id) || '-',
        role: m.cbt_member_roles?.[0]?.cbt_roles?.name || 'Siswa',
        classes: m.cbt_profiles?.cbt_class_members?.map((cm: any) => cm.cbt_classes) || [],
    }))
}

export async function isUserProctor(userId: string): Promise<boolean> {
    try {
        const member = await prisma.cbt_organization_members.findFirst({
            where: { user_id: userId }
        })
        if (!member || !member.organization_id) return false
        
        const roleData = await prisma.cbt_organization_members.findFirst({
            where: {
                user_id: userId,
                organization_id: member.organization_id
            },
            include: {
                cbt_member_roles: {
                    include: { cbt_roles: true }
                }
            }
        })
        const roleNames = (roleData?.cbt_member_roles || []).map((mr: any) => mr.cbt_roles?.name)
        return roleNames.includes('Proktor') || roleNames.includes('Admin')
    } catch {
        return false
    }
}

export async function hasUserDualRole(userId: string): Promise<boolean> {
    try {
        const member = await prisma.cbt_organization_members.findFirst({
            where: { user_id: userId }
        })
        if (!member || !member.organization_id) return false

        const roleData = await prisma.cbt_organization_members.findFirst({
            where: {
                user_id: userId,
                organization_id: member.organization_id
            },
            include: {
                cbt_member_roles: {
                    include: { cbt_roles: true }
                }
            }
        })
        const roleNames = (roleData?.cbt_member_roles || []).map((mr: any) => mr.cbt_roles?.name)
        return roleNames.includes('Proktor') && roleNames.includes('Guru')
    } catch {
        return false
    }
}

// =============================================================================
// CLASSES
// =============================================================================

export async function listOrganizationClasses(orgId: string) {
    const classes = await prisma.cbt_classes.findMany({
        where: { organization_id: orgId },
        include: {
            cbt_class_members: true
        },
        orderBy: { created_at: 'desc' }
    })
    return classes.map((c: any) => ({
        ...c,
        studentCount: c.cbt_class_members?.length || 0
    }))
}

export async function createClassAction(orgId: string, name: string, type: 'reguler' | 'tambahan', schoolYear?: string) {
    try {
        const joinCode = Math.random().toString(36).substring(2, 8).toUpperCase()
        const data = await prisma.cbt_classes.create({
            data: { organization_id: orgId, name, type, join_code: joinCode, school_year: schoolYear || null }
        })
        return { success: true, data }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function editClassAction(classId: string, name: string, type: 'reguler' | 'tambahan', schoolYear?: string) {
    try {
        await prisma.cbt_classes.update({
            where: { id: classId },
            data: { name, type, school_year: schoolYear || null }
        })
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function deleteClassAction(classId: string) {
    try {
        await prisma.cbt_classes.delete({ where: { id: classId } })
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

// =============================================================================
// EXAMS
// =============================================================================

export async function createExamAction(data: {
    orgId: string
    title: string
    description?: string
    duration: number
    examType?: 'daily' | 'pas' | 'pat' | 'pts' | 'pkn'
    subjectId?: string
    startTime?: string
    endTime?: string
    randomizeQuestions?: boolean
    randomizeOptions?: boolean
    showResults?: boolean
    isSafeMode?: boolean
    questionBankId?: string
    isPaid?: boolean
    tokenPrice?: number
    scoringType?: 'classical' | 'irt'
    isPublic?: boolean
}) {
    try {
        if (!data.title?.trim()) return { success: false, error: 'Judul ujian wajib diisi.' }
        if (data.questionBankId) {
            const bank = await prisma.cbt_question_banks.findUnique({
                where: { id: data.questionBankId },
                select: { is_published: true }
            })
            if (!bank?.is_published) return { success: false, error: 'Bank soal harus diterbitkan terlebih dahulu.' }
        }
        
        let userId: string | null = null
        try {
            const supabaseAdmin = getSupabaseAdmin()
            const { data: { user } } = await supabaseAdmin.auth.getUser()
            userId = user?.id || null
        } catch {
            // Optional user tracking
        }

        const exam = await prisma.cbt_exams.create({
            data: {
                organization_id: data.orgId,
                question_bank_id: data.questionBankId ?? null,
                title: data.title.trim(),
                description: data.description?.trim() || null,
                exam_type: data.examType || 'daily',
                duration_minutes: data.duration,
                subject_id: data.subjectId ?? null,
                start_time: data.startTime ? toUTCISO(data.startTime) : null,
                end_time: data.endTime ? toUTCISO(data.endTime) : null,
                randomize_questions: data.randomizeQuestions ?? true,
                randomize_options: data.randomizeOptions ?? true,
                show_results: data.showResults ?? false,
                is_published: false,
                status: 'draft',
                created_by: userId,
                is_paid: data.isPaid ?? false,
                token_price: data.isPaid ? (data.tokenPrice || 0) : 0,
                scoring_type: data.scoringType || 'classical',
                metadata: { is_safe_mode: data.isSafeMode ?? true, is_public: data.isPublic ?? false },
            }
        })
        return { success: true, id: exam.id }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function publishExamAction(examId: string, publish: boolean) {
    try {
        if (publish) {
            const examData = await prisma.cbt_exams.findUnique({
                where: { id: examId },
                select: { metadata: true }
            })
            const metadata = examData?.metadata as any
            const isPublic = metadata?.is_public === true
            if (!isPublic) {
                const targetsCount = await prisma.cbt_exam_targets.count({ where: { exam_id: examId } })
                if (targetsCount === 0) return { success: false, error: 'Ujian belum ditugaskan ke kelas manapun.' }
            }
            await prisma.cbt_exams.update({
                where: { id: examId },
                data: { is_published: true, status: 'active' }
            })
        } else {
            await prisma.cbt_exams.update({
                where: { id: examId },
                data: { is_published: false, status: 'draft' }
            })
        }
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function listOrganizationExams(orgId: string) {
    return prisma.cbt_exams.findMany({
        where: { organization_id: orgId },
        orderBy: { created_at: 'desc' }
    })
}

export async function getExamAttemptsAction(examId: string) {
    const attempts = await prisma.cbt_exam_attempts.findMany({
        where: { exam_id: examId },
        select: {
            id: true, status: true, total_score: true, needs_manual_grading: true,
            started_at: true, finished_at: true, tab_switch_count: true, warning_count: true,
            exam_id: true, user_id: true,
            cbt_profiles: { select: { full_name: true } }
        },
        orderBy: { started_at: 'desc' }
    })
    return attempts.map((a: any) => ({
        ...a,
        profiles: a.cbt_profiles
    }))
}

export async function assignExamAction(examId: string, classIds: string[], userIds: string[], activate: boolean = true) {
    try {
        await prisma.cbt_exam_targets.deleteMany({ where: { exam_id: examId } })
        await prisma.cbt_exam_participants.deleteMany({ where: { exam_id: examId } })
        if (classIds.length > 0) {
            const targets = classIds.map((cid) => ({ exam_id: examId, class_id: cid }))
            await prisma.cbt_exam_targets.createMany({ data: targets })
        }
        if (userIds.length > 0) {
            const participants = userIds.map((uid) => ({ exam_id: examId, user_id: uid }))
            await prisma.cbt_exam_participants.createMany({ data: participants })
        }
        if (activate) {
            await prisma.cbt_exams.update({ where: { id: examId }, data: { status: 'active' } })
        }
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

// =============================================================================
// SCHOOL YEARS
// =============================================================================

export async function listSchoolYears(orgId: string) {
    return prisma.cbt_school_years.findMany({
        where: { organization_id: orgId },
        orderBy: { year: 'desc' }
    })
}

export async function createSchoolYearAction(orgId: string, data: { year: string; startDate?: string; endDate?: string }) {
    try {
        if (!data.year?.trim()) return { success: false, error: 'Tahun ajaran wajib diisi' }
        const result = await prisma.cbt_school_years.create({
            data: { organization_id: orgId, year: data.year.trim(), start_date: data.startDate || null, end_date: data.endDate || null, is_active: false }
        })
        return { success: true, data: result }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

// =============================================================================
// SUBJECTS
// =============================================================================

export async function listSubjects(orgId: string) {
    return prisma.cbt_subjects.findMany({
        where: { organization_id: orgId },
        orderBy: { name: 'asc' }
    })
}

export async function createSubjectAction(orgId: string, data: { name: string; code?: string; color?: string }) {
    try {
        if (!data.name?.trim()) return { success: false, error: 'Nama mapel wajib diisi' }
        const result = await prisma.cbt_subjects.create({
            data: { organization_id: orgId, name: data.name.trim(), code: data.code?.trim() || null, color: data.color || '#3083FF' }
        })
        return { success: true, data: result }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}