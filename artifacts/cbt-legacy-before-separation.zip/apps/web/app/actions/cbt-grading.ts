"use server"
import { prisma } from '@/lib/prisma'
import { revalidatePath } from 'next/cache'

export type GradingResult = {
    score: number
    isCorrect: boolean | null
}

export function calculateSingleAnswerScore(
    question: any,
    rawAnswer: string | null | undefined
): GradingResult {
    const defaultAttemptScore = question.score_default || 1
    const rawOptions = question.bank_question_options || question.cbt_bank_question_options || []
    const seen = new Set<string>()
    const options = rawOptions.filter((o: any) => {
        const text = (o.option_text || '').trim()
        if (text === '') return true
        if (seen.has(text)) return false
        seen.add(text)
        return true
    })

    let scoreEarned = 0
    let isCorrect: boolean | null = false

    if (question.type === 'essay' || question.type === 'esay' || question.type === 'uraian') {
        scoreEarned = 0
        isCorrect = null
    } else if (question.type === 'mcq_complex') {
        let selectedIds: string[] = []
        try { if (rawAnswer) selectedIds = JSON.parse(rawAnswer) } catch (e) { /* noop */ }
        const correctIds = (options.filter((o: any) => o.is_correct) || []).map((o: any) => o.id)
        isCorrect =
            selectedIds.length === correctIds.length &&
            selectedIds.every((id) => correctIds.includes(id))
        scoreEarned = isCorrect ? defaultAttemptScore : 0
    } else if (question.type === 'true_false') {
        let tfAnswers: Record<string, boolean> = {}
        try { if (rawAnswer) tfAnswers = JSON.parse(rawAnswer) } catch (e) { /* noop */ }
        let correctCount = 0
        for (const opt of options) {
            if (tfAnswers[opt.id] === opt.is_correct) correctCount++
        }
        const ratio = options.length > 0 ? correctCount / options.length : 0
        scoreEarned = ratio * defaultAttemptScore
        isCorrect = ratio === 1
    } else if (question.type === 'categorization') {
        let studentCats: Record<string, string[]> = {}
        try { if (rawAnswer) studentCats = JSON.parse(rawAnswer) } catch (e) { /* noop */ }
        let correctCount = 0
        for (const opt of options) {
            const studentSelected = studentCats[opt.id] || []
            const correctCats =
                opt.metadata?.category_names ||
                (opt.metadata?.category_name ? [opt.metadata.category_name] : [])
            const isStatementCorrect =
                studentSelected.length === correctCats.length &&
                studentSelected.every((c: string) => correctCats.includes(c))
            if (isStatementCorrect) correctCount++
        }
        const ratio = options.length > 0 ? correctCount / options.length : 0
        scoreEarned = ratio * defaultAttemptScore
        isCorrect = ratio === 1
    } else if (question.type === 'matching') {
        let studentPairs: Record<string, string[]> = {}
        try { if (rawAnswer) studentPairs = JSON.parse(rawAnswer) } catch (e) { /* noop */ }
        let correctCount = 0
        for (const opt of options) {
            const studentMatches = studentPairs[opt.id] || []
            const correctMatches =
                opt.metadata?.match_texts ||
                (opt.metadata?.match_text ? [opt.metadata.match_text] : [])
            const isPairCorrect =
                studentMatches.length === correctMatches.length &&
                studentMatches.every((m: string) => correctMatches.includes(m))
            if (isPairCorrect) correctCount++
        }
        const ratio = options.length > 0 ? correctCount / options.length : 0
        scoreEarned = ratio * defaultAttemptScore
        isCorrect = ratio === 1
    } else if (question.type === 'short_answer') {
        let studentInputs: string[] = []
        try { if (rawAnswer) studentInputs = JSON.parse(rawAnswer) } catch (e) {
            if (rawAnswer) studentInputs = [rawAnswer]
        }
        const blanks = question.metadata?.blanks || []
        let correctBlanks = 0
        for (let i = 0; i < blanks.length; i++) {
            const studentInput = (studentInputs[i] || '').trim().toLowerCase()
            const variations = (blanks[i].variations || []).map((v: string) => v.trim().toLowerCase())
            const answerStr = (blanks[i].answer || '').trim().toLowerCase()
            if (studentInput === answerStr || variations.includes(studentInput)) {
                correctBlanks++
            } else {
                const matched =
                    (answerStr && (studentInput.includes(answerStr) || answerStr.includes(studentInput))) ||
                    variations.some((v: string) => studentInput.includes(v) || v.includes(studentInput))
                if (matched) correctBlanks += 0.5
            }
        }
        const ratio = blanks.length > 0 ? correctBlanks / blanks.length : 0
        scoreEarned = ratio * defaultAttemptScore
        isCorrect = ratio === 1
    } else {
        const correctOption = options.find((o: any) => o.is_correct)
        isCorrect = !!(rawAnswer && correctOption && rawAnswer === correctOption.id)
        scoreEarned = isCorrect ? defaultAttemptScore : 0
    }

    return { score: scoreEarned, isCorrect }
}

export async function regradeExamAttemptsByQuestion(questionId: string) {
    try {
        const affectedAnswers = await prisma.cbt_answers.findMany({
            where: { question_id: questionId },
            select: { attempt_id: true },
        })

        const attemptIds = [...new Set((affectedAnswers || []).map((a: any) => a.attempt_id).filter(Boolean))] as string[]
        if (attemptIds.length === 0) return

        for (const attemptId of attemptIds) {
            await regradeAttempt(attemptId)
        }
    } catch (err) {
        console.error('[Regrade] Unexpected error during regrade:', err)
    }
}

export async function regradeAttempt(attemptId: string) {
    try {
        const attempt = await prisma.cbt_exam_attempts.findUnique({
            where: { id: attemptId },
            select: { id: true, exam_id: true },
        })
        if (!attempt || !attempt.exam_id) return

        const exam = await prisma.cbt_exams.findUnique({
            where: { id: attempt.exam_id },
            select: { question_bank_id: true },
        })
        if (!exam) return

        let qbId = exam.question_bank_id
        if (!qbId) {
            const sources = await prisma.cbt_exam_question_sources.findMany({
                where: { exam_id: attempt.exam_id },
                select: { bank_id: true },
                take: 1,
            })
            if (sources && sources.length > 0) qbId = sources[0].bank_id
        }
        if (!qbId) return

        const questions = await prisma.cbt_bank_questions.findMany({
            where: { bank_id: qbId },
            select: {
                id: true,
                type: true,
                score_default: true,
                metadata: true,
                cbt_bank_question_options: {
                    select: { id: true, is_correct: true, metadata: true },
                },
            },
        })
        if (!questions) return

        const answers = await prisma.cbt_answers.findMany({
            where: { attempt_id: attemptId },
            select: { id: true, question_id: true, selected_option_id: true, essay_answer: true },
        })
        if (!answers) return

        let totalScore = 0
        let maxPossibleScore = 0
        const updatePromises: Promise<any>[] = []

        for (const q of questions) {
            const defScore = q.score_default || 1
            maxPossibleScore += defScore

            const studentAnswerRecord = answers.find((a: any) => a.question_id === q.id)
            if (!studentAnswerRecord) continue

            const isComplex = ['essay', 'esay', 'uraian', 'mcq_complex', 'true_false', 'categorization', 'matching', 'short_answer'].includes(q.type || '')
            const rawAnswer = isComplex ? studentAnswerRecord.essay_answer : studentAnswerRecord.selected_option_id

            const qMapped = {
                ...q,
                bank_question_options: q.cbt_bank_question_options,
            }

            const { score, isCorrect } = calculateSingleAnswerScore(qMapped, rawAnswer)
            totalScore += score

            updatePromises.push(
                prisma.cbt_answers.update({
                    where: { id: studentAnswerRecord.id },
                    data: { score, is_correct: isCorrect },
                })
            )
        }

        if (updatePromises.length > 0) await Promise.all(updatePromises)

        const finalScore100 = maxPossibleScore > 0 ? (totalScore / maxPossibleScore) * 100 : 0
        await prisma.cbt_exam_attempts.update({
            where: { id: attemptId },
            data: { total_score: finalScore100 },
        })
    } catch (err) {
        console.error(`[Regrade] Error regrading attempt ${attemptId}:`, err)
    }
}
