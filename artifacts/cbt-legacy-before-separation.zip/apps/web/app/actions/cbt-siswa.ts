"use server"
import { prisma } from '@/lib/prisma'
import { calculateSingleAnswerScore } from './cbt-grading'

// =============================================================================
// STUDENT / SISWA
// =============================================================================

export async function listStudentClasses(userId: string) {
    const classMembers = await prisma.cbt_class_members.findMany({
        where: { user_id: userId },
        include: {
            cbt_classes: {
                include: { cbt_organizations: true }
            }
        }
    })
    return classMembers.map((cm: any) => {
        const cls = cm.cbt_classes
        if (!cls) return null
        return {
            id: cls.id,
            name: cls.name,
            type: cls.type,
            orgName: cls.cbt_organizations?.name || 'Sekolah'
        }
    }).filter(Boolean)
}

export async function getStudentExams(userId: string) {
    const classes = await prisma.cbt_class_members.findMany({
        where: { user_id: userId },
        select: { class_id: true }
    })
    const classIds = classes.map((c: any) => c.class_id).filter(Boolean)

    let examIdsFromTargets: string[] = []
    if (classIds.length > 0) {
        const targets = await prisma.cbt_exam_targets.findMany({
            where: { class_id: { in: classIds } },
            select: { exam_id: true }
        })
        examIdsFromTargets = targets.map((t: any) => t.exam_id)
    }

    const participants = await prisma.cbt_exam_participants.findMany({
        where: { user_id: userId },
        select: { exam_id: true }
    })
    const examIdsFromParticipants = participants.map((p: any) => p.exam_id)

    const allExams = await prisma.cbt_exams.findMany({
        where: { is_published: true },
        select: { id: true, metadata: true }
    })
    const publicExamIds = allExams
        .filter((e: any) => (e.metadata as any)?.is_public === true)
        .map((e: any) => e.id)

    const examIds = [...new Set([...examIdsFromTargets, ...examIdsFromParticipants, ...publicExamIds])]
    if (examIds.length === 0) return []

    const now = new Date()
    const exams = await prisma.cbt_exams.findMany({
        where: {
            id: { in: examIds },
            is_published: true,
            OR: [
                { end_time: null },
                { end_time: { gte: now.toISOString() } }
            ]
        },
        orderBy: { start_time: 'asc' }
    })

    const attempts = await prisma.cbt_exam_attempts.findMany({
        where: { user_id: userId, exam_id: { in: examIds } },
        select: { exam_id: true, status: true }
    })
    const completedExamIds = new Set(attempts.filter((a: any) => a.status === 'submitted' || a.status === 'auto_submitted').map((a: any) => a.exam_id))
    const inProgressExamIds = new Set(attempts.filter((a: any) => a.status === 'in_progress').map((a: any) => a.exam_id))
    
    const unlocked = await prisma.cbt_unlocked_exams.findMany({
        where: { user_id: userId, exam_id: { in: examIds } },
        select: { exam_id: true }
    })
    const unlockedExamIds = new Set(unlocked.map((u: any) => u.exam_id))

    return exams.map((ex: any) => ({
        ...ex,
        isCompleted: completedExamIds.has(ex.id),
        isInProgress: inProgressExamIds.has(ex.id),
        isUnlocked: unlockedExamIds.has(ex.id) || !ex.is_paid,
        isGlobal: publicExamIds.includes(ex.id) || (ex.metadata as any)?.is_public === true,
    }))
}

/**
 * Start or resume an exam attempt. All time checks use server time.
 */
export async function startExamAttemptAction(userId: string, examId: string) {
    try {
        const serverNow = new Date()

        const exam = await prisma.cbt_exams.findUnique({
            where: { id: examId },
            select: { organization_id: true, question_bank_id: true, is_published: true, start_time: true, end_time: true, duration_minutes: true, metadata: true }
        })
        if (!exam) return { success: false, error: 'Ujian tidak ditemukan' }
        if (!exam.is_published) return { success: false, error: 'Ujian belum dipublikasikan.' }

        if (exam.start_time && serverNow < new Date(exam.start_time)) {
            const startDate = new Date(exam.start_time)
            const wibDate = new Date(startDate.getTime() + 7 * 60 * 60 * 1000)
            const hours = String(wibDate.getUTCHours()).padStart(2, '0')
            const minutes = String(wibDate.getUTCMinutes()).padStart(2, '0')
            return { success: false, error: `Ujian belum dimulai. Window dibuka pk ${hours}:${minutes} WIB.` }
        }
        if (exam.end_time && serverNow > new Date(exam.end_time)) return { success: false, error: 'Waktu ujian telah berakhir.' }

        const completedAttempt = await prisma.cbt_exam_attempts.findFirst({
            where: {
                user_id: userId,
                exam_id: examId,
                status: { in: ['submitted', 'auto_submitted'] }
            },
            select: { id: true, status: true }
        })
        if (completedAttempt) return { success: false, error: 'Anda sudah menyelesaikan ujian ini.' }

        const existingAttempt = await prisma.cbt_exam_attempts.findFirst({
            where: {
                user_id: userId,
                exam_id: examId,
                status: 'in_progress'
            }
        })
        if (existingAttempt) {
            if (existingAttempt.personal_end_time && serverNow > new Date(existingAttempt.personal_end_time)) {
                await prisma.cbt_exam_attempts.update({
                    where: { id: existingAttempt.id },
                    data: { status: 'auto_submitted', finished_at: serverNow.toISOString() }
                })
                return { success: false, error: 'Waktu ujian telah berakhir.' }
            }
            const personalEnd = new Date(existingAttempt.personal_end_time!)
            const remainingSeconds = Math.max(0, Math.floor((personalEnd.getTime() - serverNow.getTime()) / 1000))
            if (remainingSeconds <= 0) {
                await prisma.cbt_exam_attempts.update({
                    where: { id: existingAttempt.id },
                    data: { status: 'auto_submitted', finished_at: serverNow.toISOString() }
                })
                return { success: false, error: 'Durasi ujian telah habis.' }
            }
            const savedAnswers = await prisma.cbt_answers.findMany({
                where: { attempt_id: existingAttempt.id },
                select: { question_id: true, selected_option_id: true, essay_answer: true, is_doubtful: true }
            })
            return { success: true, attempt: existingAttempt, answers: savedAnswers || [], remainingSeconds }
        }

        const duration = exam.duration_minutes || 60
        let personalEndTime = new Date(serverNow.getTime() + duration * 60 * 1000)
        if (exam.end_time) {
            const windowClose = new Date(exam.end_time)
            if (windowClose < personalEndTime) personalEndTime = windowClose
        }

        const newAttempt = await prisma.cbt_exam_attempts.create({
            data: {
                organization_id: exam.organization_id,
                exam_id: examId,
                user_id: userId,
                status: 'in_progress',
                started_at: serverNow.toISOString(),
                personal_end_time: personalEndTime.toISOString(),
            }
        })

        const remainingSeconds = Math.max(0, Math.floor((personalEndTime.getTime() - serverNow.getTime()) / 1000))
        return { success: true, attempt: newAttempt, answers: [], remainingSeconds }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function saveAnswerAction(attemptId: string, questionId: string, data: { selected_option_id?: string; essay_answer?: string; is_doubtful?: boolean }) {
    try {
        await prisma.cbt_answers.upsert({
            where: {
                attempt_id_question_id: { attempt_id: attemptId, question_id: questionId }
            },
            create: {
                attempt_id: attemptId,
                question_id: questionId,
                selected_option_id: data.selected_option_id || null,
                essay_answer: data.essay_answer || null,
                is_doubtful: data.is_doubtful ?? false
            },
            update: {
                selected_option_id: data.selected_option_id || null,
                essay_answer: data.essay_answer || null,
                is_doubtful: data.is_doubtful ?? false
            }
        })
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}

export async function submitExamAction(userId: string, examId: string, studentAnswers: Record<string, string>) {
    if (!userId) return { success: false, error: 'Not authenticated' }
    try {
        const exam = await prisma.cbt_exams.findUnique({
            where: { id: examId },
            select: { organization_id: true, question_bank_id: true }
        })
        if (!exam) return { success: false, error: 'Ujian tidak ditemukan' }

        let qbId = exam.question_bank_id
        if (!qbId) {
            const sources = await prisma.cbt_exam_question_sources.findFirst({
                where: { exam_id: examId },
                select: { bank_id: true }
            })
            if (sources) qbId = sources.bank_id
        }
        if (!qbId) return { success: false, error: 'Tidak ada bank soal terkait' }

        const questions = await prisma.cbt_bank_questions.findMany({
            where: { bank_id: qbId },
            select: {
                id: true, type: true, score_default: true, metadata: true,
                cbt_bank_question_options: { select: { id: true, is_correct: true, metadata: true } }
            }
        })
        if (!questions) return { success: false, error: 'Gagal memuat soal untuk grading' }

        let totalScore = 0
        let maxPossibleScore = 0
        let hasEssay = false
        const answerRecordsToInsert: any[] = []

        for (const q of questions) {
            const defScore = q.score_default || 1
            maxPossibleScore += defScore
            const rawAnswer = studentAnswers[q.id]
            if (['essay', 'esay', 'uraian'].includes(q.type)) hasEssay = true
            const formattedQ = { ...q, bank_question_options: q.cbt_bank_question_options }
            const { score, isCorrect } = calculateSingleAnswerScore(formattedQ, rawAnswer)
            totalScore += score
            if (rawAnswer || ['essay', 'esay', 'uraian', 'mcq_complex', 'true_false', 'categorization', 'matching', 'short_answer'].includes(q.type)) {
                answerRecordsToInsert.push({
                    question_id: q.id,
                    selected_option_id: ['essay', 'esay', 'uraian', 'mcq_complex', 'true_false', 'categorization', 'matching', 'short_answer'].includes(q.type) ? null : rawAnswer,
                    essay_answer: ['essay', 'esay', 'uraian', 'mcq_complex', 'true_false', 'categorization', 'matching', 'short_answer'].includes(q.type) ? rawAnswer : null,
                    score,
                    is_correct: isCorrect,
                })
            }
        }

        const finalScore100 = maxPossibleScore > 0 ? (totalScore / maxPossibleScore) * 100 : 0
        
        const existingInProgress = await prisma.cbt_exam_attempts.findFirst({
            where: { user_id: userId, exam_id: examId, status: 'in_progress' },
            select: { id: true }
        })
        if (!existingInProgress) return { success: false, error: 'Gagal memperbarui status ujian.' }

        const attempt = await prisma.cbt_exam_attempts.update({
            where: { id: existingInProgress.id },
            data: {
                status: 'submitted',
                needs_manual_grading: hasEssay,
                finished_at: new Date().toISOString(),
                total_score: finalScore100,
            }
        })

        for (const record of answerRecordsToInsert) {
            await prisma.cbt_answers.updateMany({
                where: { attempt_id: attempt.id, question_id: record.question_id },
                data: { score: record.score, is_correct: record.is_correct }
            })
        }
        return { success: true, score: finalScore100 }
    } catch (err: any) {
        return { success: false, error: err.message }
    }
}

export async function getStudentResultsAction(userId: string) {
    if (!userId) return []
    const attempts = await prisma.cbt_exam_attempts.findMany({
        where: { user_id: userId },
        include: {
            cbt_exams: {
                select: { title: true, duration_minutes: true, show_results: true, scoring_type: true }
            }
        },
        orderBy: { finished_at: 'desc' }
    })
    return attempts.map((a: any) => ({
        ...a,
        exams: a.cbt_exams
    }))
}

export async function getAttemptDetailsAction(attemptId: string, userId: string) {
    const attempt = await prisma.cbt_exam_attempts.findUnique({
        where: { id: attemptId },
        include: {
            cbt_exams: {
                select: { id: true, title: true, show_results: true, question_bank_id: true, scoring_type: true }
            }
        }
    })
    if (!attempt || attempt.user_id !== userId) return null
    if (attempt.cbt_exams?.show_results !== true) return null

    const answers = await prisma.cbt_answers.findMany({
        where: { attempt_id: attemptId },
        include: {
            cbt_bank_questions: {
                include: {
                    cbt_bank_question_options: {
                        select: { id: true, option_text: true, is_correct: true, weight: true }
                    }
                }
            }
        }
    })

    return {
        attempt: {
            ...attempt,
            exams: attempt.cbt_exams
        },
        answers: (answers || []).map((a: any) => ({
            id: a.id,
            questionId: a.question_id,
            selectedOptionId: a.selected_option_id,
            essayAnswer: a.essay_answer,
            isCorrect: a.is_correct,
            score: a.score,
            question: a.cbt_bank_questions ? {
                id: a.cbt_bank_questions.id,
                question_text: a.cbt_bank_questions.question_text,
                type: a.cbt_bank_questions.type,
                score_default: a.cbt_bank_questions.score_default,
                metadata: a.cbt_bank_questions.metadata,
                options: a.cbt_bank_questions.cbt_bank_question_options || []
            } : null,
        })),
    }
}

export async function getTokenBalanceAction(userId: string) {
    if (!userId) return 0
    const profile = await prisma.cbt_profiles.findUnique({
        where: { id: userId },
        select: { token_balance: true }
    })
    return profile?.token_balance || 0
}

export async function unlockExamAction(userId: string, examId: string) {
    if (!userId || !examId) return { success: false, error: 'Invalid input' }
    try {
        const exam = await prisma.cbt_exams.findUnique({
            where: { id: examId },
            select: { is_paid: true, token_price: true, title: true }
        })
        if (!exam) return { success: false, error: 'Exam not found' }
        if (!exam.is_paid) return { success: true }

        const profile = await prisma.cbt_profiles.findUnique({
            where: { id: userId },
            select: { token_balance: true }
        })
        const balance = profile?.token_balance || 0
        const price = exam.token_price || 0
        if (balance < price) return { success: false, error: 'Saldo token tidak mencukupi' }

        await prisma.cbt_profiles.update({
            where: { id: userId },
            data: { token_balance: balance - price }
        })
        await prisma.cbt_token_transactions.create({
            data: { user_id: userId, amount: -price, type: 'usage', description: `Membuka akses ujian: ${exam.title}`, reference_id: examId }
        })
        await prisma.cbt_unlocked_exams.upsert({
            where: {
                user_id_exam_id: { user_id: userId, exam_id: examId }
            },
            create: { user_id: userId, exam_id: examId },
            update: {}
        })
        return { success: true }
    } catch (error: any) {
        return { success: false, error: error.message }
    }
}