'use client'

import { useDashboardUser } from '@/components/UserContext'
import { CBTNilaiPlaceholder } from '@/components/cbt/CBTPlaceholders'

export default function Page() {
    const { user } = useDashboardUser()
    if (!user) return null
    return <CBTNilaiPlaceholder user={user} />
}
