'use client'

import { useDashboardUser } from '@/components/UserContext'
import { CBTDashboardPlaceholder } from '@/components/cbt/CBTPlaceholders'

export default function Page() {
    const { user } = useDashboardUser()
    if (!user) return null
    return <CBTDashboardPlaceholder user={user} />
}
