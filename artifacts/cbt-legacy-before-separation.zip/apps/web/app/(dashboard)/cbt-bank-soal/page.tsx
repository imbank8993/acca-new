'use client'

import { useDashboardUser } from '@/components/UserContext'
import { CBTBankSoalPlaceholder } from '@/components/cbt/CBTPlaceholders'

export default function Page() {
    const { user } = useDashboardUser()
    if (!user) return null
    return <CBTBankSoalPlaceholder user={user} />
}
