'use client'

import { useDashboardUser } from '@/components/UserContext'
import { CBTUjianPlaceholder } from '@/components/cbt/CBTPlaceholders'

export default function Page() {
    const { user } = useDashboardUser()
    if (!user) return null
    return <CBTUjianPlaceholder user={user} />
}
