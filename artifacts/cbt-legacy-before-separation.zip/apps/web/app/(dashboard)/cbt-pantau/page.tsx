'use client'

import { useDashboardUser } from '@/components/UserContext'
import { CBTPantauPlaceholder } from '@/components/cbt/CBTPlaceholders'

export default function Page() {
    const { user } = useDashboardUser()
    if (!user) return null
    return <CBTPantauPlaceholder user={user} />
}
