import { createClient, SupabaseClient } from '@supabase/supabase-js'
import { prisma } from './prisma'
import { createPrismaDbAdapter } from './prisma-db-adapter'

let _client: SupabaseClient | null = null
let _proxiedClient: any = null

const adapter = createPrismaDbAdapter(prisma)

const CBT_TABLE_MAP: Record<string, string> = {
    'organization_members': 'cbt_organization_members',
    'organizations': 'cbt_organizations',
    'question_banks': 'cbt_question_banks',
    'exams': 'cbt_exams',
    'classes': 'cbt_classes',
    'class_members': 'cbt_class_members',
    'exam_targets': 'cbt_exam_targets',
    'exam_attempts': 'cbt_exam_attempts',
    'exam_participants': 'cbt_exam_participants',
    'school_years': 'cbt_school_years',
    'subjects': 'cbt_subjects',
    'bank_questions': 'cbt_bank_questions',
    'bank_question_options': 'cbt_bank_question_options',
    'bank_folders': 'cbt_bank_folders',
    'exam_attempt_questions': 'cbt_exam_attempt_questions',
    'question_stimuli': 'cbt_question_stimuli',
    'question_instructions': 'cbt_question_instructions',
    'attempt_security_logs': 'cbt_attempt_security_logs',
    'unlocked_exams': 'cbt_unlocked_exams',
    'answers': 'cbt_answers',
    'exam_question_sources': 'cbt_exam_question_sources',
    'profiles': 'cbt_profiles',
    'token_transactions': 'cbt_token_transactions',
}

function getCbtTableName(table: string): string {
    if (CBT_TABLE_MAP[table]) return CBT_TABLE_MAP[table]
    if (table.startsWith('cbt_')) return table
    return `cbt_${table}`
}

export function getSupabaseAdmin(): SupabaseClient {
    if (_proxiedClient) return _proxiedClient

    const supabaseUrl = process.env.NEXT_PUBLIC_CBT_SUPABASE_URL || 'https://placeholder.supabase.co'
    const supabaseServiceRoleKey = process.env.CBT_SUPBOARD_SERVICE_KEY || process.env.CBT_SUPABASE_SERVICE_KEY || 'placeholder-key'

    _client = createClient(supabaseUrl, supabaseServiceRoleKey, {
        auth: { autoRefreshToken: false, persistSession: false },
    })

    _proxiedClient = new Proxy(_client, {
        get(target, prop, receiver) {
            if (prop === 'from') {
                return (table: string) => adapter.from(getCbtTableName(table))
            }
            const val = Reflect.get(target, prop, receiver)
            return typeof val === 'function' ? val.bind(target) : val
        }
    })

    return _proxiedClient as SupabaseClient
}

export const supabase = (() => {
    const url = process.env.NEXT_PUBLIC_CBT_SUPABASE_URL || 'https://placeholder.supabase.co'
    const key = process.env.NEXT_PUBLIC_CBT_SUPABASE_ANON_KEY || 'placeholder-key'

    const rawClient = createClient(url, key, {
        auth: {
            autoRefreshToken: true,
            persistSession: true,
            detectSessionInUrl: true,
        },
    })

    return new Proxy(rawClient, {
        get(target, prop, receiver) {
            if (prop === 'from') {
                return (table: string) => adapter.from(getCbtTableName(table))
            }
            const val = Reflect.get(target, prop, receiver)
            return typeof val === 'function' ? val.bind(target) : val
        }
    })
})()